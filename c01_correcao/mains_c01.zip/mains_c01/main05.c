/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcampos- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/07 19:52:20 by tcampos-          #+#    #+#             */
/*   Updated: 2019/12/09 07:50:21 by tcampos-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);

int		main(void)
{
/*	char	letra;
	char	vetor[10];
	int		contador;

	contador = 0;
	letra = 'a';
	while (contador < 10)
	{
		vetor[contador] = letra;
		letra++;
		contador++;
	}
	ft_putstr(vetor);
	return (0);
}*/
char frase[] = {"Uma frase qualquer"};
ft_putstr(frase);
}
